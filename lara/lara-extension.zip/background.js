// LARA browser extension.
// Click the toolbar button on a journal article page: LARA reads the paper's DOI
// from the page and opens a check for a legal free copy.
// Right-click selected text (a DOI or a title) for the same.
// The extension only reads the page you click it on (activeTab); it collects nothing.
const LARA = "https://shagbaor.com/lara/";

function open(params) {
  const q = new URLSearchParams(params).toString();
  chrome.tabs.create({ url: LARA + (q ? "?" + q : "") + "#request" });
}

// Runs inside the article page.
function findPaper() {
  const pick = (sel) => { const m = document.querySelector(sel); return m && m.content ? m.content.trim() : ""; };
  const isDoi = (v) => /10\.\d{4,9}\/\S+/.test(v);
  const clean = (v) => v.replace(/^(https?:\/\/(dx\.)?doi\.org\/|doi:\s*)/i, "").trim();
  const metas = ['meta[name="citation_doi"]', 'meta[name="dc.identifier"]', 'meta[name="DC.identifier"]',
    'meta[name="dc.Identifier"]', 'meta[name="prism.doi"]', 'meta[name="bepress_citation_doi"]', 'meta[property="citation_doi"]'];
  for (const s of metas) { const v = pick(s); if (isDoi(v)) return { doi: clean(v.match(/10\.\d{4,9}\/\S+/)[0]) }; }
  const fromUrl = decodeURIComponent(location.href).match(/10\.\d{4,9}\/[^\s?#&"'<>]+/);
  if (fromUrl) return { doi: clean(fromUrl[0]) };
  const text = document.body ? document.body.innerText.slice(0, 30000) : "";
  const inText = text.match(/10\.\d{4,9}\/[^\s"'<>]+/);
  if (inText) return { doi: clean(inText[0]).replace(/[.,;)\]]+$/, "") };
  const title = pick('meta[name="citation_title"]') || pick('meta[property="og:title"]') || pick('meta[name="dc.title"]');
  return title ? { title } : {};
}

chrome.action.onClicked.addListener(async (tab) => {
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: findPaper });
    const r = (res && res.result) || {};
    if (r.doi) return open({ doi: r.doi });
    if (r.title) return open({ q: r.title });
    open({});
  } catch {
    open({}); // browser pages (settings, new tab) cannot be read: just open LARA
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "lara-selection", title: "Find on LARA: “%s”", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "lara-link", title: "Find this link's paper on LARA", contexts: ["link"] });
});

chrome.contextMenus.onClicked.addListener((info) => {
  const raw = info.menuItemId === "lara-link" ? info.linkUrl || "" : info.selectionText || "";
  const doi = decodeURIComponent(raw).match(/10\.\d{4,9}\/[^\s"'<>?#]+/);
  if (doi) return open({ doi: doi[0].replace(/[.,;)\]]+$/, "") });
  if (info.menuItemId === "lara-selection" && raw.trim().length > 8) return open({ q: raw.trim().slice(0, 300) });
  open({});
});
