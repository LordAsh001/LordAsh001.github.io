# Nigeria Energy Atlas v1.0

Snapshot of https://shagbaor.com/energy-atlas/ taken 2026-10-12.

- `app/` — the complete web application (open `app/energy-atlas/index.html` from a local web server, e.g. `python -m http.server`), its data files, the data bots (`scripts/energy_atlas`, `.github/workflows`) and their tests.
- `data/` — the full data package (CSV, GeoJSON, JSON) with its own README, licence and citation file.

Licences: code MIT; compiled data and text CC BY 4.0; third-party data keep their own terms (see data/README.md).

Author: Shagbaor Hycent Amool (ORCID 0000-0001-8460-6744), University of Northern British Columbia.
