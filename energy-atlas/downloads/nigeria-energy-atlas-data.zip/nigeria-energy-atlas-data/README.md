# Nigeria Energy Atlas — data package

Built 2026-11-13 from https://shagbaor.com/energy-atlas/ by Shagbaor Hycent Amool (ORCID 0000-0001-8460-6744).
This package holds every dataset shown in the atlas. It is rebuilt automatically when the atlas's data bots update it.

## Files
- `csv/disco_atcc_losses_2026q1.csv`
- `csv/energy_indices.csv`
- `csv/energy_sites.csv`
- `csv/generation_by_source_twh.csv`
- `csv/grid_collapses_per_year.csv`
- `csv/grid_events.csv`
- `csv/grid_news_unverified.csv`
- `csv/headline_figures.csv`
- `csv/live_data_links.csv`
- `csv/nerc_publications.csv`
- `csv/nerc_quarterly.csv`
- `csv/petrol_import_share.csv`
- `csv/pipelines.csv`
- `csv/power_projects.csv`
- `csv/resource_potential.csv`
- `csv/rise_scores.csv`
- `csv/sources.csv`
- `csv/state_profiles.csv`
- `csv/wef_nexus_index.csv`
- `csv/world_bank_indicators.csv`
- `geojson/energy_sites_and_pipelines.geojson`
- `geojson/nigeria_states_geoboundaries.geojson`
- `json/all_data.json`

CSV files are UTF-8 (with BOM, so they open correctly in Excel). Coordinates are WGS84 longitude/latitude.

## What each file contains
- **energy_sites.csv / energy_sites_and_pipelines.geojson** — power plants, refineries, LNG, oil and gas provinces, coal and bitumen, nuclear and research sites, with capacity, status and notes. Locations are approximate (typically within a few km); some markers (basins, programmes) are symbolic. Pipeline routes are schematic.
- **state_profiles.csv** — zone, indicative solar resource band (kWh/m²/day, from the national north–south gradient — not measured site values), qualitative wind class, distribution company and electricity regulator for each state (regulator status as reported to Aug 2025).
- **nigeria_states_geoboundaries.geojson** — state boundaries from geoBoundaries (Nigeria ADM1, 2022; source GRID3), simplified for web display.
- **generation_by_source_twh.csv** — grid electricity generation by source (Our World in Data, from Ember and the Energy Institute).
- **world_bank_indicators.csv** — access to electricity (national/urban/rural), clean cooking, electricity use per person, renewable share and T&D losses (World Bank WDI API).
- **nerc_quarterly.csv, disco_atcc_losses_2026q1.csv** — NERC quarterly reports.
- **grid_collapses_per_year.csv, grid_events.csv** — national grid collapse record; each row names its source. Sources disagree; NERC is used from 2021.
- **energy_indices.csv, rise_scores.csv, wef_nexus_index.csv** — index results with sources.
- **power_projects.csv** — register of power-sector projects and programmes, each with a source and status date.
- **headline_figures.csv, resource_potential.csv, petrol_import_share.csv** — figures quoted on the atlas pages, with sources.
- **nerc_publications.csv, grid_news_unverified.csv** — lists collected by the atlas bots. News items are unverified headlines.
- **sources.csv, live_data_links.csv** — references and live-data links.
- **all_data.json** — everything above in one JSON file.

## Licence and credit
- Datasets compiled for this atlas (sites, state profiles, projects register, grid-collapse record, headline figures) and all text: © 2026 Shagbaor Hycent Amool, licensed CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
- World Bank WDI and RISE data: CC BY 4.0, © World Bank. Generation data: Our World in Data / Ember, CC BY 4.0. Boundaries: geoBoundaries (Runfola et al. 2020, PLoS ONE 15(4): e0231866), CC BY 4.0. WEF Nexus Index: Simpson et al. (2022), Frontiers in Water 4:825854.
- Figures quoted from NERC, NUPRC, TCN/NISO, NMDPRA, NOSDRA, index publishers and news reports are cited facts with links to the original sources. Check those publishers' terms before republishing their documents.
- The data are indicative and provided for education, research and planning discussion — not for engineering or investment decisions.

## Cite
Amool, S. H. (2026). Nigeria Energy Atlas (Version 1.0) [Software and dataset]. Zenodo. https://doi.org/10.5281/zenodo.23307712 — live atlas: https://shagbaor.com/energy-atlas/
